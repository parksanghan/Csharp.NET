﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace WpfApp4
{
    internal class Manager
    {
        public Client client = null;
        
        const string SERVER_IP = "127.0.0.1";
        const int SERVER_PORT = 7000;
        public MainWindow win = null;
       
        public void LogDel( Log log, string msg)
        {
            //string temp = string.Format(log.ToString() + "\t" + msg);
            //Console.WriteLine(temp);
        }
        #region 싱글톤
        public static Manager Instance { get; private set; } = null;
        static Manager()
        {
            Instance = new Manager();

        }
        private Manager()
        {
            client = new Client(SERVER_IP, SERVER_PORT, RecvDel, LogDel);
        }
        #endregion

        #region 시작 끝(네트워크 연결, 종료)
        public bool Load()
        {
            bool ret = client.Start();

            return ret;
        }

        public void FormClosed()
        {
            client.Stop();
        }
        #endregion 

        #region Callback
        public void RecvDel(Socket s, string msg)
        {
            string[] sp = msg.Split('\a');
            if (sp[0] == "insertack")
            {
                FunctionInsert(s, sp[1]);
            }
            else if (sp[0] == "deleteack")
            {
                Functiondelete(s, sp[1]);
            }
            else if (sp[0] == "updateack")
            {
                FunctionUpdate(s, sp[1]);
            }
            else if (sp[0] == "printallack")
            {
               Books books=  FunctionAll(sp[1]);
                win.setlist(books);
            }
        }
        public void FunctionInsert(Socket s, string msg)
        {
            string[] sp = msg.Split('#');
            bool result = bool.Parse(sp[0]);
            string meg = result ? "저장성공" : "저장실패";
            MessageBox.Show(msg);
        }
        public void Functiondelete(Socket s , string msg)
        {
            string[] sp = msg.Split('#');
            bool result = bool.Parse(sp[0]);
            string mess = result ? "저장성공" : "저장실패";
            MessageBox.Show(mess);
        }
        public void FunctionUpdate(Socket s ,string msg)
        {
            string[] sp = msg.Split('#');
            bool result = bool.Parse(sp[0]);
            string mess = result ? "저장성공" : "저장실패";
            MessageBox.Show(mess);

        }

        public Books FunctionAll(string msg)
        {
            Books books = new Books();
            string[] sp = msg.Split('@');
            foreach (string  dd in sp)
            {

                if (dd==string.Empty) continue;
                string[] ssp  = dd.Split('#');
                string title = ssp[0];
                string pub = ssp[1];
                string writer = ssp[2];
                int pr = int.Parse(ssp[3]);
                books.Add(new Book() { Title = title, Publisher = pub, Writer = writer, Price = pr });
            }
            return books;

        }

        public void LogDel(Socket s, Log log, string msg)
        {
            //string temp = string.Format(log.ToString() + "\t" + msg);
            //Console.WriteLine(temp);
        }
        #endregion






    }
}
