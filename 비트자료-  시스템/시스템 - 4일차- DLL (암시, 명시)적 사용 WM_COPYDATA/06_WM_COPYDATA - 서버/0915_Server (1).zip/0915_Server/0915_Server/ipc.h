//ipc.h
#pragma once

void ipc_GetControlHandle(HWND hDlg);

void ipc_PrintMessage(HWND hDlg, const TCHAR* msg);





