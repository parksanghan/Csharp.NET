//Control.h
#pragma once

void con_Init(HWND hDlg);

void con_OnCopyData(HWND hDlg, WPARAM wParam, LPARAM lParam);