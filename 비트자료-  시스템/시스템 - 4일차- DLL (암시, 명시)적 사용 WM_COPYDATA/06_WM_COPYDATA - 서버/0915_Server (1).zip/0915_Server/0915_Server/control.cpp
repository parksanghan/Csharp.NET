//Control.cpp
#include "std.h"

void con_Init(HWND hDlg)
{
	ipc_GetControlHandle(hDlg);
}

void con_OnCopyData(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	ipc_PrintMessage(hDlg, TEXT("�ڵ� ����...."));
}