﻿//ipc.cpp
#include "std.h"

HWND hList_Print;

void ipc_GetControlHandle(HWND hDlg)
{
	hList_Print = GetDlgItem(hDlg, IDC_LIST_PRINT);
}

void ipc_PrintMessage(HWND hDlg, const TCHAR* msg)
{
	SYSTEMTIME time;
	GetLocalTime(&time);

	TCHAR buf[100];
	wsprintf(buf, TEXT("%s (%02d:%02d:%02d)"), 
		msg, time.wHour, time.wMinute, time.wSecond);

	SendMessage(hList_Print, LB_ADDSTRING, 0, (LPARAM)buf);
}
