﻿//ipc.cpp
#include "std.h"

HWND hList_Print, hEdit_Print;

void ui_GetControlHandle(HWND hDlg)
{
	hList_Print = GetDlgItem(hDlg, IDC_LIST_PRINT);
	hEdit_Print = GetDlgItem(hDlg, IDC_EDIT_PRINT);
}

void ui_MsgPrint(HWND hDlg, void* p)
{
	PACKET* pack = (PACKET*)p;

	TCHAR buf[100];
	wsprintf(buf, TEXT("[%s] %s (%02d:%02d:%02d)"),
		pack->nickname, pack->msg, 
		pack->dt.wHour, pack->dt.wMinute, pack->dt.wSecond);

	SendMessage(hEdit_Print, EM_REPLACESEL, 0, (LPARAM)buf);
	SendMessage(hEdit_Print, EM_REPLACESEL, 0, (LPARAM)TEXT("\r\n"));
}

void ui_PacketPrint(HWND hDlg, vector<PACKET> packets)
{
	SendMessage(hList_Print, LB_RESETCONTENT, 0, 0);

	for (int i = 0; i < packets.size(); i++)
	{
		PACKET pack = packets[i];

		TCHAR buf[50];
		wsprintf(buf, TEXT("%d(%s)"), (int)pack.hwnd, pack.nickname);

		SendMessage(hList_Print, LB_ADDSTRING, 0, (LPARAM)buf);
	}
}
