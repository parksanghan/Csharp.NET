//mynet.h
#pragma once

vector<PACKET> mynet_Connect(void* pdata);
vector<PACKET> mynet_DisConnect(void* pdata);

void mynet_RecvData(void* pdata);