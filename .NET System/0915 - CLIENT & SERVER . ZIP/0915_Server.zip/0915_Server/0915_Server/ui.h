//ipc.h
#pragma once

void ui_GetControlHandle(HWND hDlg);

void ui_MsgPrint(HWND hDlg, void* p);
void ui_PacketPrint(HWND hDlg, vector<PACKET> packets);





